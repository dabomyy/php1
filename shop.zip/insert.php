<?
include "dbconn.php";

$name=$_POST['name'];
$comment=$_POST['comment'];
$memo=$_POST['memo'];
$price=$_POST['price'];


$uploads_dir = './data'; // 실제 이미지 저장공간
$allowed_ext = array('jpg','jpeg','png','gif');

$error = $_FILES['img']['error'];
$aname = $_FILES['img']['name'];
$ext = array_pop(explode('.', $aname)); //.을 기준으로 분리해서 배열해라

if($error != UPLOAD_ERR_OK){
  switch($error){
    case UPLOAD_ERR_INI_SIZE:
    case UPLOAD_ERR_FORM_SIZE:
      echo "파일이 너무 큽니다. ($error)";
      break;

    case UPLOAD_ERR_NO_FILE:
      echo "파일이 첨부되지 않았습니다. ($error)";
      break;

    default:
      echo "파일이 제대로 업로드되지 않았습니다. ($error)";
  }
  exit; //이미지 업로드 성공
}

if (!in_array($ext, $allowed_ext)){
  echo "허용되지 않은 확장자입니다.";
  exit;
}

move_uploaded_file($_FILES['img']['tmp_name'],"$uploads_dir/$aname");
//임시에서 실제 저장 공간으로 이동

$sql = "insert into shop (name,comment,memo,price,img)";
$sql .= "values('$name','$comment','$memo','$price','$aname')";

mysqli_query($connect,$sql);
mysqli_Close($connect);
?>

<script>
  location.href="shop_list.php";
</script>