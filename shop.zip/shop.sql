create table shop(
  no int(11) not null auto_increment,
  name varchar(50) not null,
  comment varchar(200) not null,
  memo text not null,
  price int(11) not null,
  img varchar(30),
  primary key(no)
)engine=innoDB charset=utf8;