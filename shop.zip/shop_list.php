<?
include "dbconn.php";

$name=$_POST['name'];
$comment=$_POST['comment'];
$memo=$_POST['memo'];
$price=$_POST['price'];

$sql="select * from shop";
$result=mysqli_query($connect,$sql);
?>

<style>
  body {
    margin: 30px;
  }
  *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  table {
    width: 80%;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    border-collapse: collapse;
  }
  p {
    width: 80%;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 20px;
  }
</style>

<table width="80%" border="1">
  <tr>
    <td>상품명</td>
    <td>이미지</td>
    <td>금액</td>
    <td>기타</td>
    <td>삭제</td>
  </td>

<?
  while($data=mysqli_fetch_array($result)){
?> 

<tr>
  <td><?=$data['name']?></td>
  <td><img src="./data/<?=$data['img']?>"></td>
  <td><?=number_format($data['price'])."원"?></td>
  <td><?=$data['memo']?></td>
  <td><a href="delete.php?name=<?=$data['name']?>">삭제</a></td>
</tr>
<?  
  }
  mysqli_close($connect);
?>
  <p><a href="list.php">장바구니폼</a></p>
</table>  

