<?
session_start();

$name=$_GET['name'];

include "dbconn.php";

$sql = "delete from shop where name = '$name'";
mysqli_query($connect, $sql);
mysqli_close($connect);

echo "
  <script>
  location.href = 'shop_list.php';
  </script>
";
?>
