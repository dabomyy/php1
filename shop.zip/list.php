<?php
include "dbconn.php";
?>
  <ul>
    <li>상품추가
      <form action="insert.php" method="post" enctype="multipart/form-data">
        <table width="70%" border="1">
          <tr>
            <td>상품명</td>
            <td><input type="text" name="name" size="30"></td>
          </tr>
          <tr>
            <td>짧은설명</td>
            <td><input type="text" name="comment" size="50"></td>
          </tr>
          <tr>
            <td>금액</td>
            <td><input type="text" name="price" size="10"></td>
          </tr>
          <tr>
            <td>설명</td>
            <td><textarea name="memo" id="" cols="60" rows="10"></textarea></td>
          </tr>
          <tr>
            <td>사진</td>
            <td><input type="file" name="img" size="10"></td>
          </tr>
          <tr>
            <td><input type="submit" value="등록">
          </tr>
        </table>
      </form>
    </li>
  </ul>

            