<?php
include "dbconn.php";
?>
<style>
  body {
    margin: 100px;
  }
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  .box {
    display: flex;
    width: 80%;
    margin-left: auto;
    margin-right: auto;
  }
  ul {
    width: 25%;
    margin-bottom: 50px;
    padding-right: 5px;
  }
  li {
    list-style: none;
  }
  span {
    display: block;
    text-align: center;
    height: 25px;
    line-height:25px;
  }
  img {
    width: 100%;
  }
</style>
<h2>상품추가</h2>
<div class="box">

  <ul>
    <form action="insert.php" method="post" enctype="multipart/form-data">
      <li> 
        <p><input type="hidden" name="img" alt="img" value="img/m1.png"></p>
        <p><img src="img/m1.png" alt="image" width="238" height="257"></p>
        <span><input type="hidden" name="name" value="green pad">green pad</span>
        <span><input type="hidden" name="comment" value="그린패드">그린패드</span>
        <span><input type="hidden" name="price" value="20000">20000</span>
        <span><input type="hidden" name="memo" value="1st rank">1st rank</span>
        <span><input type="image" src="img/shop_s.png" alt="shop"></span>
      </li>  
    </form>
  </ul>

  <ul>
    <form action="insert.php" method="post" enctype="multipart/form-data">
      <li>
        <p><input type="hidden" name="img" alt="img" value="img/m2.png"></p>
        <p><img src="img/m2.png" alt="image" width="238" height="257"></p>
        <span><input type="hidden" name="name" value="
green tangerine serum">green tangerine serum</span>
        <span><input type="hidden" name="comment" value="청귤세럼">청귤세럼</span>
        <span><input type="hidden" name="price" value="28000">28000</span>
        <span><input type="hidden" name="memo" value="2nd rank">2nd rank</span>
        <span><input type="image" src="img/shop_s.png" alt="shop"></span>
      </li>  
    </form>
  </ul>

  <ul>
    <form action="insert.php" method="post" enctype="multipart/form-data">
      <li> 
        <p><input type="hidden" name="img" alt="img" value="img/m3.png"></p>
        <p><img src="img/m3.png" alt="image" width="238" height="257"></p>
        <span><input type="hidden" name="name" value="yuzu lotion">yuzu lotion</span>
        <span><input type="hidden" name="comment" value="유자로션">유자로션</span>
        <span><input type="hidden" name="price" value="40000">40000</span>
        <span><input type="hidden" name="memo" value="3rd rank">3rd rank</span>
        <span><input type="image" src="img/shop_s.png" alt="shop"></span>
      </li>  
    </form>
  </ul>

  <ul>
    <form action="insert.php" method="post" enctype="multipart/form-data">
      <li>
        <p><input type="hidden" name="img" alt="img" value="img/m4.png"></p>
        <p><img src="img/m4.png" alt="image" width="238" height="257"></p>
        <span><input type="hidden" name="name" value="mild pad">mild pad</span>
        <span><input type="hidden" name="comment" value="순한 패드">순한 패드</span>
        <span><input type="hidden" name="price" value="18000">18000</span>
        <span><input type="hidden" name="memo" value="4th rank">4th rank</span>
        <span><input type="image" src="img/shop_s.png" alt="shop"></span>
      </li>  
    </form>
  </ul>

</div>
            