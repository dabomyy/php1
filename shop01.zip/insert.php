<?
include "dbconn.php";

$img=$_POST['img'];
$name=$_POST['name'];
$comment=$_POST['comment'];
$memo=$_POST['memo'];
$price=$_POST['price'];


$sql = "insert into shop1 (name,comment,memo,price,img)";
$sql .= "values('$name','$comment','$memo','$price','$img')";

mysqli_query($connect,$sql);
mysqli_Close($connect);
?>

<script>
  location.href="shop_list.php";
</script>