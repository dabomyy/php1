<?
include "dbconn.php";

$name=$_POST['name'];
$comment=$_POST['comment'];
$memo=$_POST['memo'];
$price=$_POST['price'];
$img=$_POST['img'];

$sql="select * from shop1";
$result=mysqli_query($connect,$sql);
?>

<style>
  table {
    margin: 1rem auto;
    text-align: center;
    border-collapse: collapse;
  }

</style>

<table width="80%" border="1">
  <tr>
    <td>상품명</td>
    <td>이미지</td>
    <td>금액</td>
    <td>기타</td>
    <td>삭제</td>
  </tr>

<?
  while($data=mysqli_fetch_array($result)){
?> 

<tr>
  <td><?=$data['name']?></td>
  <td><img src="./<?=$data['img']?>"></td> <!--현재폴더에 이미지 넣기-->
  <td><?=number_format($data['price'])."원"?></td>
  <td><?=$data['memo']?></td>
  <td><a href="delete.php?name=<?=$data['name']?>">삭제</a></td>
</tr>
<?  
  }
  mysqli_close($connect);
?>
  <p><a href="list.php">장바구니폼</a></p>
</table>  

